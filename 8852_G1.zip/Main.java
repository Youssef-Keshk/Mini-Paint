package Backend;
import Windows.PaintWindow;

public class Main {
    public static void main(String[] args) {
        new PaintWindow();
    }
}
